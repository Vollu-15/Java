package LoopingStatements;

import java.util.Scanner;

public class SumOfNaturalNumbers {

	public static void main(String[] args)
	{
		int n=10,sum=0;
		  
		  for(int i=1;i<=n;++i)
		  {
			  sum = sum +i;
		  }
			  System.out.println("sum of first 10 natural numbers:"+sum);
				  
			  
		  }

	}


