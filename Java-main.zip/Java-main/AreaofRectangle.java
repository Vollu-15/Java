package LoopingStatements;

public class AreaofRectangle 
{
	public  double calculateRectangleArea(double length,double width)
	{
		double Area=length*width;
	
  return Area;
}
}