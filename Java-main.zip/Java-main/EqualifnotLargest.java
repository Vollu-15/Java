package Looping;

public class EqualifnotLargest 
{
	public int Number(int x,int y,int z)
	{
		if(x == y && y==z)
			{
				System.out.println("given three numbers are equal");
			}
			else
			{
				System.out.println("largest number");
			}
		
		return x;
	}

}
